# GEITE01X – Living in the I.T. Era
### Interactive React Course Orientation Presentation | National University Clark

**Academic Year:** 2026–2027, 2nd Term  
**Sections:** MED204 / MED205 (BS Medical Technology, Year 2)  
**Course:** 3 units lecture, 4 lecture hours per week  
**Final course requirement:** Certiport IC3 Digital Literacy GS6, Level 1 – Foundations

A slide-by-slide, full-screen, animated orientation portal with a white translucent glass style, navy-blue text, red highlights, yellow accents, and the original professor photo and NU logo supplied by the instructor.

## 1. Requirements

- Windows, macOS, or Linux
- **Node.js 18 or newer** (Node.js 20 LTS or newer recommended)
- npm (included with Node.js)
- A modern browser: Chrome, Edge, Firefox, etc.
- Internet access **only for the initial package installation**. The actual orientation app has no cloud API or external font requirement.

Check your installation in a command prompt or terminal:

```bash
node -v
npm -v
```

If Node.js is missing, install it from https://nodejs.org/ and reopen the terminal.

## 2. Run the project locally (development)

1. Extract the ZIP to your desired folder, e.g., `Desktop/GEITE01X_Orientation_Portal`.
2. Open that folder in **Visual Studio Code**.
3. Open **Terminal → New Terminal** in VS Code.
4. Install dependencies (first time only):

   ```bash
   npm install
   ```

5. Start the web app:

   ```bash
   npm run dev
   ```

6. Open the local URL shown in the terminal (normally **http://localhost:5173/**).
7. Press **F** or use the maximize button at the top-right to present fullscreen.

**Windows shortcut:** In File Explorer, open the extracted project directory, type `cmd` in the address bar, press Enter, and run `npm install` followed by `npm run dev`.

## 3. Presentation navigation

| Action | Control |
|---|---|
| Next slide | Right arrow →, Page Down, or bottom right button |
| Previous slide | Left arrow ←, Page Up, or bottom left button |
| First / last slide | Home / End |
| Enter/exit fullscreen | F or top-right fullscreen icon |
| Show shortcut help | ? or top-right question-mark icon |
| Phone/tablet | Swipe left or right |

There is **no traditional navbar or scrolling** on ordinary classroom/projector screens. On narrower mobile screens, slide content may scroll vertically to remain accessible.

## 4. Using the Student Name & Question Randomizer

1. Navigate to **slide 24 of 25**: *Random Student Picker*.
2. Select **MED204** or **MED205**.
3. Click **Manage students**.
4. Paste student names **one per line**, or import a `.txt` / `.csv` file. To use a CSV, make sure it has a `Name` header with a single full name per row (example in `samples/roster-template.csv`).
5. Click **Replace list**. Alternatively, click **+ Add names** to add names without removing previously saved names.
6. Close the roster dialog and click **Pick Student & Question**.
7. The system animates the name selection and then shows one of **45 icebreaker questions**.
8. Click **New question** if a different question is needed for the same selected student.
9. Click **Pick Student & Question** again to continue. Selected names are not drawn again until the round is reset.

**IMPORTANT:** MED204 and MED205 rosters and draw histories are kept separate. Student names, the selection history, and the last question are saved in the current browser's `localStorage`. They are **not uploaded to a server**. If you use another computer/browser, you will need to import the roster again. Clearing browser/site data also clears these rosters. For privacy, use a trusted instructor-controlled computer.

**Demo mode:** The roster manager has a **Load demo names** button. Demo entries are clearly marked. Replace them before presenting to an actual class.

**Reset:** *Reset this round* clears the selection history and used questions for the active section, without deleting its student roster. Editing the roster also resets the drawn student history.

## 5. What is included

- **25 animated presentation slides** (course details, IC3 GS6 Level 1, seven core domains, professor introduction, attendance and uniform policies, digital learning, grading scheme, grade equivalents, certification, icebreaker and closing).
- Official **NU logo** (`public/assets/nu-logo.svg`) supplied by the instructor.
- Instructor **photo** (`public/assets/professor-ej-diaz.png`) supplied by the instructor.
- True 45-question randomizer and separate student rosters for MED204/MED205.
- Grade formula example with live demonstration sliders (not real student grades).
- Keyboard navigation, fullscreen, animations, glass cards, responsive layouts, reduced-motion support.
- No registration/login or database needed to run the orientation presentation.

### What the portal intentionally does NOT implement

The **Student Grade Portal** slide is an **orientation concept preview only**. It does *not* contain real grades, a student login, or a database. Actual grade lookup requires a separate backend/database, secure authentication, authorized user access, and appropriate privacy safeguards. This project avoids inventing student grade records.

### Attendance scoring note

The instructor supplied -0.5 point for lateness after the 15-minute grace period, -1 point for more than 30 minutes of lateness, and an 80% trimester attendance requirement. The official grading scheme lists 60% learning activities and 40% examination in each term, but does not specify the **attendance subcomponent weight**. This portal therefore **presents** the rules and does not invent an automatic attendance grade algorithm. Confirm school requirements before using any automated grade deductions.

### Certification scoring note

The official IC3 GS6 Level 1 certification exam is the course's final requirement. The university document separately specifies a 40% final exam component. How Certiport's result is translated into the course grade must follow approved university or instructor procedures and is not automatically assumed by this project.

## 6. Change text, questions or images

| Task | File |
|---|---|
| Update course details and 45 questions | `src/courseData.js` |
| Edit presentation slide content | `src/App.jsx` (`SlideContent` switch) |
| Change design/colors and animations | `src/styles.css` (`:root` variables and style classes) |
| Replace NU logo | `public/assets/nu-logo.svg` |
| Replace professor photo | `public/assets/professor-ej-diaz.png` |

The uploaded original branding assets have been used **without editing the person's face or redesigning the logo**.

## 7. Create a production build

```bash
npm run build
```

This produces the production-ready `dist/` folder. To preview it locally:

```bash
npm run preview
```

You can deploy `dist/` to a static hosting service such as Netlify, Cloudflare Pages, or Vercel. The Vite config uses a relative base path so it can be hosted in a subdirectory.

**Do not simply double-click `dist/index.html` using `file://`**. Modern ES module builds often require an HTTP server. Use `npm run preview` or a static web server.

## 8. Troubleshooting

**`node` is not recognized:** Install Node.js, then restart the terminal.

**`npm install` fails:** Confirm internet connectivity, disable a misconfigured proxy/VPN or use an approved network. Try `npm cache verify`, then `npm install` again.

**Port 5173 is busy:** Vite will print a new port in the terminal. Open that address instead.

**Logo or photo not visible:** Check that `public/assets/nu-logo.svg` and `public/assets/professor-ej-diaz.png` exist and restart `npm run dev`.

**Fullscreen does not work:** Use a normal browser tab (not an embedded preview), or press F11 in your browser.

**Missing student roster:** Import your TXT/CSV list in the roster manager. Roster data is stored per browser; private/incognito windows may discard it automatically.

**Text too small/large on projector:** Use browser zoom (`Ctrl` + `+` / `Ctrl` + `-`) or change the projector display resolution. For best results use a 16:9 screen and full-screen mode.

---

**Built for:** GEITE01X – Living in the I.T. Era · NU Clark · MED204 & MED205 · AY 2026–2027, 2nd Term.
