import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { course, competencies, gradeEquivalents, icebreakers } from '../src/courseData.js';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const check = (ok, message) => { if (!ok) throw new Error(message); console.log('✓', message); };
check(course.code === 'GEITE01X', 'Course code GEITE01X');
check(course.sections.join(',') === 'MED204,MED205', 'MED204 and MED205 sections');
check(competencies.length === 7, 'All seven IC3 GS6 competencies included');
check(gradeEquivalents.length === 8, 'All eight university grade-equivalence rows included');
check(icebreakers.length === 45, 'All 45 icebreaker questions included');
check(new Set(icebreakers.map(q=>q.text)).size === 45, 'Questions are unique');
check(icebreakers.every(q=>q.text && q.category), 'Every question has text and category');
for (const asset of ['nu-logo.svg','professor-ej-diaz.png']) {
  check(fs.existsSync(path.join(root,'public','assets',asset)), `Original asset ${asset} is included`);
}
check(fs.existsSync(path.join(root,'src','App.jsx')), 'React presentation source exists');
check(fs.existsSync(path.join(root,'src','styles.css')), 'Glassmorphism theme CSS exists');
console.log('Orientation source checks passed.');
