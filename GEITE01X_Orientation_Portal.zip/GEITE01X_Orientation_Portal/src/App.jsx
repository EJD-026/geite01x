import { useCallback, useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import {
  ArrowLeft, ArrowRight, Award, BadgeCheck, BookOpen, BrainCircuit, CalendarDays,
  Check, CheckCircle2, ChevronLeft, ChevronRight, CircleAlert, CircleHelp,
  ClipboardCheck, ClipboardList, Clock3, Cpu, Eye, FileCheck2, FilePenLine,
  Fingerprint, Globe2, GraduationCap, HeartPulse, Keyboard, Laptop,
  Lightbulb, LockKeyhole, Maximize2, MessageCircle, MessagesSquare, Mic2, Minimize2,
  MonitorPlay, MousePointer2, PenLine, Presentation, RotateCcw, Search,
  Settings2, ShieldAlert, ShieldCheck, Shuffle, Smartphone, Sparkles, Star, Target,
  Timer, Trophy, Upload, UserCircle2, UsersRound, Wifi, X, Zap
} from 'lucide-react';
import { competencies, course, demoStudents, gradeEquivalents, icebreakers } from './courseData.js';

const ASSETS = import.meta.env.BASE_URL + 'assets/';
const slides = [
  { label:'Welcome', section:'OPENING' },
  { label:'Course at a glance', section:'OUR COURSE' },
  { label:'Course description', section:'OUR COURSE' },
  { label:'Why it matters for MedTech', section:'OUR COURSE' },
  { label:'Our certification goal', section:'IC3 CERTIFICATION' },
  { label:'Seven IC3 domains', section:'IC3 CERTIFICATION' },
  { label:'Our learning journey', section:'IC3 CERTIFICATION' },
  { label:'Learning outcomes', section:'OUR COURSE' },
  { label:'Meet your professor', section:'MEET YOUR PROFESSOR' },
  { label:'How we learn', section:'OUR CLASSROOM' },
  { label:'Classroom policies', section:'CLASS POLICIES' },
  { label:'Attendance monitoring', section:'CLASS POLICIES' },
  { label:'Absences and breaks', section:'CLASS POLICIES' },
  { label:'Digital classroom', section:'CLASS ACTIVITIES' },
  { label:'Quiz and assessment rules', section:'CLASS ACTIVITIES' },
  { label:'Midterm grading', section:'GRADING SYSTEM' },
  { label:'Final-term grading', section:'GRADING SYSTEM' },
  { label:'Final course grade', section:'GRADING SYSTEM' },
  { label:'Grade equivalents', section:'GRADING SYSTEM' },
  { label:'Transparency promise', section:'GRADE TRANSPARENCY' },
  { label:'Student grade portal', section:'GRADE TRANSPARENCY' },
  { label:'Final requirement', section:'CERTIFICATION' },
  { label:'Let’s connect', section:'ICEBREAKER ACTIVITY' },
  { label:'Student name & question picker', section:'ICEBREAKER ACTIVITY' },
  { label:'Closing message', section:'SEE YOU IN CLASS' },
];

const iconLookup = { Cpu, Globe2, Search, FilePenLine, MessagesSquare, UsersRound, ShieldCheck };
const savedKey = 'geite01x_v1_';
function useStoredState(key, initialValue) {
  const [value, setValue] = useState(() => {
    try {
      const raw = localStorage.getItem(savedKey + key);
      return raw ? JSON.parse(raw) : initialValue;
    } catch { return initialValue; }
  });
  useEffect(() => {
    try { localStorage.setItem(savedKey + key, JSON.stringify(value)); } catch { /* storage may be disabled */ }
  }, [key, value]);
  return [value, setValue];
}
function uniqueNames(names) {
  const seen = new Set();
  return names.map(n => String(n || '').replace(/^\s*\d+[.)]\s*/, '').trim())
    .filter(n => { const key = n.toLocaleLowerCase(); if (!n || seen.has(key)) return false; seen.add(key); return true; });
}
function parseCsvRow(row) {
  const parts = []; let cell = '', quoted = false;
  for (let i = 0; i < row.length; i++) {
    if (row[i] === '"') { if (quoted && row[i+1] === '"') { cell += '"'; i++; } else quoted = !quoted; }
    else if (row[i] === ',' && !quoted) { parts.push(cell.trim()); cell = ''; }
    else cell += row[i];
  }
  parts.push(cell.trim()); return parts;
}
function parseNameList(text) {
  const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  if (!lines.length) return [];
  const rows = lines.map(parseCsvRow);
  const header = rows[0].map(v => v.replace(/^\uFEFF/, '').toLowerCase().replace(/[ _-]/g,''));
  const nameCol = header.findIndex(h => ['name','studentname','fullname','completename'].includes(h));
  const firstCol = header.findIndex(h => ['firstname','givenname'].includes(h));
  const lastCol = header.findIndex(h => ['lastname','surname','familyname'].includes(h));
  const hasHeader = nameCol !== -1 || firstCol !== -1 || lastCol !== -1;
  const values = (hasHeader ? rows.slice(1) : rows).map(parts => {
    if (nameCol !== -1) return parts[nameCol] || '';
    if (firstCol !== -1 || lastCol !== -1) return [parts[firstCol] || '',parts[lastCol] || ''].filter(Boolean).join(' ');
    return parts[0] || '';
  });
  return uniqueNames(values);
}
function IconCard({ icon: Icon, title, description, accent='blue', number }) {
  return <div className={'glass-card feature-card accent-' + accent}>
    <div className="feature-icon"><Icon size={24} strokeWidth={1.9}/></div>
    {number && <span className="feature-number">{number}</span>}
    <h3>{title}</h3><p>{description}</p>
  </div>;
}
function Tile({ icon:Icon, value, label, accent='blue' }) {
  return <div className={'glass-card metric accent-' + accent}>
    <div className="metric-icon"><Icon size={22}/></div>
    <strong>{value}</strong><span>{label}</span>
  </div>;
}
function FrameTitle({ eyebrow, title, description, important }) {
  return <div className="frame-title">
    <div className="eyebrow"><span className="eyebrow-dot"/>{eyebrow}</div>
    <h1>{title}{important && <> <span className="red-accent">{important}</span></>}</h1>
    <div className="highlight-rule" />
    {description && <p>{description}</p>}
  </div>;
}
function Callout({ icon:Icon=Lightbulb, children, type='blue' }) {
  return <div className={'callout callout-' + type}><Icon size={22}/><span>{children}</span></div>;
}
function Bar({ name, value, accent='blue' }) {
  return <div className="bar-row"><div className="bar-label"><strong>{name}</strong><b>{value}%</b></div><div className="bar-track"><div className={'bar-fill '+ accent} style={{width: value+'%'}}/></div></div>;
}
function InfoStack({ items }) {
  return <div className="info-stack">{items.map((item, i) => <div className="info-line" key={i}>
    <span className="info-line-icon"><item.icon size={22}/></span><div><b>{item.title}</b><span>{item.text}</span></div>
  </div>)}</div>;
}
function GradeTable() {
  return <div className="grade-list glass-card">
    <div className="grade-list-header"><span>GRADE RANGE (%)</span><span>GRADE POINT</span></div>
    {gradeEquivalents.map((g,i)=><div className={'grade-list-row '+(i===6?'passing-row':'')} key={g.range}>
      <span>{g.range}</span><strong>{g.point}</strong>
    </div>)}
  </div>;
}
function GradeCalculator() {
  const [mid,setMid] = useState(85);
  const [final,setFinal] = useState(90);
  const result = (Number(mid)+Number(final))/2;
  return <div className="glass-card calculator">
    <div className="calculator-heading"><Zap size={21}/><b>Interactive grade example</b><span>Try changing the values</span></div>
    <label htmlFor="mid-grade">Midterm: <strong>{mid}%</strong></label>
    <input id="mid-grade" type="range" min="0" max="100" value={mid} onChange={e=>setMid(e.target.value)} />
    <label htmlFor="final-grade">Final term: <strong>{final}%</strong></label>
    <input id="final-grade" type="range" min="0" max="100" value={final} onChange={e=>setFinal(e.target.value)} />
    <div className="result-strip"><span>Weighted final course grade</span><strong>{result.toFixed(2)}%</strong></div>
    <small>Illustration only; actual grades and rounding follow official university records.</small>
  </div>;
}

function parseError(error) { return error instanceof Error ? error.message : String(error); }
function Randomizer({ isActive }) {
  const [section,setSection] = useState('MED204');
  const [rosters,setRosters] = useStoredState('rosters', { MED204:[], MED205:[] });
  const [drawn,setDrawn] = useStoredState('drawn', { MED204:[], MED205:[] });
  const [asked,setAsked] = useStoredState('asked', { MED204:[], MED205:[] });
  const [selected,setSelected] = useStoredState('lastSelections', { MED204:null, MED205:null });
  const [rolling,setRolling] = useState(false);
  const [rollingName,setRollingName] = useState('');
  const [rosterOpen,setRosterOpen] = useState(false);
  const [bulkText,setBulkText] = useState('');
  const [notice,setNotice] = useState('');
  const rollInterval = useRef(null);
  const rollTimeout = useRef(null);
  const sectionNames = Array.isArray(rosters[section]) ? rosters[section] : [];
  const previous = Array.isArray(drawn[section]) ? drawn[section] : [];
  const remaining = sectionNames.filter(n=>!previous.includes(n));
  const current = selected[section];
  const cancelRolling = useCallback(() => {
    clearInterval(rollInterval.current); clearTimeout(rollTimeout.current); setRolling(false);
  }, []);
  useEffect(() => () => { clearInterval(rollInterval.current); clearTimeout(rollTimeout.current); }, []);
  useEffect(() => { if (!isActive) cancelRolling(); }, [isActive, cancelRolling]);
  useEffect(()=>{ const fn = e=>{ if(e.key === 'Escape' && rosterOpen) setRosterOpen(false); }; window.addEventListener('keydown',fn);return ()=>window.removeEventListener('keydown',fn); },[rosterOpen]);

  function drawStudent() {
    if (!remaining.length || rolling) return;
    const name = remaining[Math.floor(Math.random()*remaining.length)];
    const priorQuestions = Array.isArray(asked[section]) ? asked[section] : [];
    let available = icebreakers.map((_,i)=>i).filter(i=>!priorQuestions.includes(i));
    if (!available.length) available = icebreakers.map((_,i)=>i);
    const questionIndex = available[Math.floor(Math.random()*available.length)];
    setSelected(prev=>({...prev,[section]:null})); setRollingName(remaining[0]); setRolling(true);
    let ticks = 0;
    rollInterval.current = setInterval(()=>{
      setRollingName(remaining[Math.floor(Math.random()*remaining.length)]);
      ticks += 1;
      if (ticks >= 20) clearInterval(rollInterval.current);
    }, 65);
    rollTimeout.current = setTimeout(()=>{
      clearInterval(rollInterval.current);
      setRolling(false);
      setDrawn(prev=>({...prev,[section]:[...(prev[section]||[]),name]}));
      setAsked(prev=>({...prev,[section]:priorQuestions.length===icebreakers.length?[questionIndex]:[...priorQuestions,questionIndex]}));
      setSelected(prev=>({...prev,[section]:{ name, questionIndex }}));
    }, 1400);
  }
  function rerollQuestion() {
    if (!current || rolling) return;
    const priorQuestions = Array.isArray(asked[section])?asked[section]:[];
    let remainingQuestions = icebreakers.map((_,i)=>i).filter(i=>!priorQuestions.includes(i));
    if (!remainingQuestions.length) remainingQuestions=icebreakers.map((_,i)=>i).filter(i=>i!==current.questionIndex);
    if (!remainingQuestions.length) return;
    const index = remainingQuestions[Math.floor(Math.random()*remainingQuestions.length)];
    setAsked(prev=>({...prev,[section]:priorQuestions.length===icebreakers.length?[index]:[...priorQuestions,index]}));
    setSelected(prev=>({...prev,[section]:{...current,questionIndex:index}}));
  }
  function saveNames(mode='replace') {
    const names = parseNameList(bulkText);
    if (!names.length) { setNotice('Add at least one valid student name.'); return; }
    const updated = mode === 'append' ? uniqueNames([...sectionNames,...names]) : names;
    setRosters(prev=>({...prev,[section]:updated}));
    setDrawn(prev=>({...prev,[section]:[]}));
    setAsked(prev=>({...prev,[section]:[]}));
    setSelected(prev=>({...prev,[section]:null}));
    setNotice(`${updated.length} names saved for ${section}. Your draw history was reset.`);
    setBulkText('');
  }
  function resetDraw() {
    if (!window.confirm(`Reset picked names and questions for ${section}? The student roster will remain saved.`)) return;
    cancelRolling(); setDrawn(prev=>({...prev,[section]:[]})); setAsked(prev=>({...prev,[section]:[]}));
    setSelected(prev=>({...prev,[section]:null})); setNotice(`${section} is ready for a new round.`);
  }
  function loadDemo() {
    cancelRolling(); setRosters(prev=>({...prev,[section]:[...demoStudents]}));
    setDrawn(prev=>({...prev,[section]:[]})); setAsked(prev=>({...prev,[section]:[]}));
    setSelected(prev=>({...prev,[section]:null})); setNotice('Demo names added. Replace with your real class list before presenting.');
    setRosterOpen(false);
  }
  async function fileChosen(e) {
    const file = e.target.files?.[0]; if (!file) return;
    try { setBulkText(await file.text()); setNotice(`Loaded ${file.name}. Select Replace or Add Names to save.`); }
    catch (err) { setNotice('Could not read the file: ' + parseError(err)); }
    e.target.value='';
  }
  return <div className="randomizer-layout">
    <div className="glass-card randomizer-main">
      <div className="random-head">
        <div><div className="eyebrow small"><span className="eyebrow-dot"/>LIVE CLASS ACTIVITY</div><h2>Who’s up next?</h2></div>
        <div className="class-switch" aria-label="Select class section">
          {course.sections.map(s=><button key={s} type="button" className={s===section?'active':''} onClick={()=>{cancelRolling();setSection(s);setNotice('')}}>{s}</button>)}
        </div>
      </div>
      <div className="random-result" aria-live="polite">
        <div className="name-caption"><Sparkles size={18}/> RANDOMLY SELECTED STUDENT</div>
        <AnimatePresence mode="wait">
          {rolling ? <motion.h2 key="rolling" initial={{opacity:0,scale:0.92}} animate={{opacity:1,scale:1}} exit={{opacity:0,scale:1.06}} className="rolling-text">{rollingName}</motion.h2>
          : current ? <motion.h2 key={section+current.name} initial={{opacity:0,y:18,scale:.94}} animate={{opacity:1,y:0,scale:1}} exit={{opacity:0}} className="result-name">{current.name}</motion.h2>
          : <motion.h2 key={section+'empty'} initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="result-placeholder">{sectionNames.length?'Ready to pick a student!':'Add your class roster to begin'}</motion.h2>}
        </AnimatePresence>
        {current && !rolling ? <motion.div className="question-reveal" initial={{opacity:0,y:14}} animate={{opacity:1,y:0}} transition={{delay:.25}}>
          <span className="question-category"><MessageCircle size={16}/> {icebreakers[current.questionIndex].category}</span>
          <p>{icebreakers[current.questionIndex].text}</p>
        </motion.div> : <div className="question-wait">{rolling?'Selecting a new student and question…':'Introduce yourself, then answer the question that appears.'}</div>}
      </div>
      <div className="random-actions">
        <button className="btn primary large" onClick={drawStudent} disabled={!remaining.length||rolling}><Shuffle size={20}/>{rolling?'Picking…':remaining.length?'Pick Student & Question':'All Students Picked'}</button>
        <button className="btn outline" onClick={rerollQuestion} disabled={!current||rolling}><RotateCcw size={18}/>New question</button>
      </div>
    </div>
    <div className="random-side">
      <div className="glass-card pool-stats">
        <div className="side-title"><UsersRound size={21}/><strong>{section} Student List</strong></div>
        <div className="pool-numbers"><div><b>{sectionNames.length}</b><span>Students</span></div><div><b>{previous.length}</b><span>Selected</span></div><div><b>{remaining.length}</b><span>Remaining</span></div></div>
        <div className="tiny-progress"><span style={{width:(sectionNames.length?previous.length/sectionNames.length*100:0)+'%'}}/></div>
        <button className="btn outline wide" onClick={()=>{setRosterOpen(true);setBulkText('');setNotice('')}}><Settings2 size={18}/> Manage students</button>
        <button className="btn subtle wide" onClick={resetDraw} disabled={!previous.length&&!asked[section]?.length}><RotateCcw size={17}/> Reset this round</button>
      </div>
      <div className="glass-card random-tip">
        <Lightbulb size={22}/><div><b>How to play</b><span>Student says their name, nickname, and one interesting fact—then answers the random question.</span></div>
      </div>
      {notice && <div className="toast-inline" role="status">{notice}</div>}
    </div>
    {rosterOpen && <div className="modal-scrim" role="presentation" onMouseDown={e=>{if(e.target===e.currentTarget)setRosterOpen(false)}}>
      <motion.div initial={{opacity:0,scale:.95,y:20}} animate={{opacity:1,scale:1,y:0}} className="roster-modal" role="dialog" aria-modal="true" aria-label="Manage student roster">
        <div className="modal-top"><div><span className="eyebrow">STUDENT ROSTER</span><h2>Manage {section} Names</h2></div><button className="icon-button" onClick={()=>setRosterOpen(false)} aria-label="Close student roster"><X/></button></div>
        <p>Enter one name per line or import a <b>.txt / .csv</b> file. A CSV may have a <b>Name</b> column. Names are stored only in this browser (localStorage).</p>
        <textarea value={bulkText} placeholder={'Maria Santos\nJuan Dela Cruz\nAna Reyes'} onChange={e=>setBulkText(e.target.value)} rows={6} aria-label="Names, one per line" />
        <div className="modal-buttons">
          <label className="btn outline" htmlFor="student-file"><Upload size={17}/> Import TXT / CSV</label>
          <input id="student-file" type="file" accept=".txt,.csv,text/plain,text/csv" className="sr-only" onChange={fileChosen}/>
          <button className="btn primary" onClick={()=>saveNames('replace')}><Check size={17}/>Replace list</button>
          <button className="btn outline" onClick={()=>saveNames('append')}>+ Add names</button>
        </div>
        {notice && <div className="modal-notice" role="status">{notice}</div>}
        <div className="modal-foot"><span>{sectionNames.length} saved names · {remaining.length} still available this round</span>
          <div className="modal-foot-buttons"><button type="button" className="link-button" onClick={loadDemo}>Load demo names</button><button type="button" className="link-button danger" onClick={()=>{if(window.confirm(`Delete the entire ${section} roster?`)){setRosters(p=>({...p,[section]:[]}));setDrawn(p=>({...p,[section]:[]}));setAsked(p=>({...p,[section]:[]}));setSelected(p=>({...p,[section]:null}));setNotice('Roster cleared.');}}}>Clear roster</button></div>
        </div>
      </motion.div>
    </div>}
  </div>;
}

function SlideContent({ index, isActive }) {
  switch(index) {
    case 0: return <div className="hero-layout">
      <div className="hero-left"><div className="eyebrow"><span className="eyebrow-dot"/>ACADEMIC YEAR {course.academicYear} · {course.term.toUpperCase()}</div>
        <h1>WELCOME TO<br/><span className="hero-blue">LIVING IN THE</span><br/><span className="hero-red">I.T. ERA</span><span className="hero-dot">.</span></h1>
        <div className="highlight-rule hero-rule"/>
        <p>Your digital literacy journey starts here. <strong>Learn. Practice. Certify.</strong></p>
        <div className="hero-tags"><span><BookOpen size={16}/>GEITE01X</span><span><GraduationCap size={16}/>MED204 · MED205</span><span><Award size={16}/>IC3 GS6 Level 1</span></div>
      </div>
      <div className="hero-right"><div className="hero-graphic">
        <div className="hero-ring ring-1"/><div className="hero-ring ring-2"/>
        <div className="hero-core"><MonitorPlay size={86} strokeWidth={1.25}/><span>THE DIGITAL ERA</span></div>
        <div className="float-chip chip-one"><Wifi/> Connected</div>
        <div className="float-chip chip-two"><ShieldCheck/> Protected</div>
        <div className="float-chip chip-three"><BrainCircuit/> Inspired</div>
      </div></div>
    </div>;
    case 1: return <><FrameTitle eyebrow="THE BASICS" title="Your course at a" important="glance" description="Everything you need to know before we begin."/>
      <div className="grid-four"><Tile icon={BookOpen} value="GEITE01X" label="Course code"/><Tile icon={GraduationCap} value="3 Units" label="Lecture"/><Tile icon={Clock3} value="4 Hours" label="Lecture each week"/><Tile icon={CalendarDays} value="2nd Term" label="AY 2026–2027" accent="red"/></div>
      <div className="glass-card wide-banner"><div><h3>{course.title}</h3><span>BS Medical Technology · Second Year</span></div><div className="pill-row"><span>MED204</span><span>MED205</span></div></div>
    </>;
    case 2: return <><FrameTitle eyebrow="ABOUT THE COURSE" title="What is Living in the" important="I.T. Era?" description="Foundational digital knowledge for academic life, healthcare, and the workplace."/>
      <div className="course-description glass-card"><div className="desc-icon"><Globe2 size={62}/></div><p>GEITE01X develops students' <b>foundational digital literacy</b>, practical technology skills, and responsible use of information and communication technologies. It covers the seven core competencies of <b>Certiport IC3 Digital Literacy GS6</b> and uses hands-on, certification-focused learning designed for <b>non-IT students</b>.</p></div>
      <div className="grid-three"><IconCard icon={Laptop} title="Understand" description="Recognize essential digital tools and computing concepts."/><IconCard icon={MousePointer2} title="Apply" description="Practice digital skills through approachable tasks."/><IconCard icon={Award} title="Prepare" description="Build readiness for GS6 Level 1 – Foundations." accent="red"/></div>
    </>;
    case 3: return <><FrameTitle eyebrow="YOUR FUTURE PROFESSION" title="Technology meets" important="Medical Technology" description="Digital competence is essential in modern healthcare practice."/>
      <div className="grid-two big-tiles"><IconCard icon={HeartPulse} title="Modern Laboratories" description="Digital instruments and laboratory information systems help organize and communicate results."/><IconCard icon={ShieldCheck} title="Patient Data Privacy" description="Protect confidential records and share information only through authorized channels." accent="red"/><IconCard icon={Search} title="Reliable Research" description="Find credible healthcare information and verify sources before trusting digital content."/><IconCard icon={UsersRound} title="Professional Collaboration" description="Work responsibly with colleagues using online communication and shared resources."/></div>
      <Callout icon={Lightbulb}>You do not need to become a programmer. You need to become a confident, responsible user of technology.</Callout>
    </>;
    case 4: return <><FrameTitle eyebrow="OUR MAIN GOAL" title="A certification-focused" important="course" description="Your final course requirement is the official Certiport IC3 examination."/>
      <div className="cert-focus"><div className="glass-card cert-hero"><div className="cert-emblem"><Award size={77}/></div><span className="red-label">CERTIPORT · IC3 DIGITAL LITERACY</span><h2>GLOBAL STANDARD SIX</h2><strong>LEVEL 1 — FOUNDATIONS</strong><p>Demonstrates fundamental digital literacy knowledge and basic digital competencies.</p></div><div className="cert-side"><IconCard icon={Target} title="Targeted Preparation" description="Lessons, quizzes, and reviews aligned to foundational digital literacy."/><IconCard icon={ClipboardCheck} title="Final Requirement" description="Take the official IC3 GS6 Level 1 – Foundations certification examination." accent="red"/></div></div>
    </>;
    case 5: return <><FrameTitle eyebrow="GLOBAL STANDARD SIX" title="The seven core" important="competencies" description="IC3 GS6 measures the same seven domains at different levels. We focus on Level 1."/>
      <div className="domain-grid">{competencies.map((c,i)=>{ const Icon=iconLookup[c.icon]||Sparkles;return <div className="glass-card domain-card" key={c.title}><div className="domain-number">0{i+1}</div><div className="domain-icon"><Icon size={27}/></div><h3>{c.title}</h3><p>{c.note}</p></div>; })}</div>
    </>;
    case 6: return <><FrameTitle eyebrow="OUR LEARNING MODEL" title="LEARN. PRACTICE." important="CERTIFY." description="We will follow the Learn → Practice → Certify approach throughout the term."/>
      <div className="journey-grid"><div className="glass-card journey-card"><div className="journey-num">01</div><BookOpen/><h2>LEARN</h2><p>Clear and simple discussions, examples, and guided demonstrations.</p></div><div className="journey-connector"><ArrowRight size={32}/></div><div className="glass-card journey-card"><div className="journey-num">02</div><MousePointer2/><h2>PRACTICE</h2><p>Digital quizzes, hands-on exercises, tasks, reviews, and mock examinations.</p></div><div className="journey-connector"><ArrowRight size={32}/></div><div className="glass-card journey-card featured"><div className="journey-num">03</div><Award/><h2>CERTIFY</h2><p>Demonstrate readiness for the official IC3 GS6 Level 1 examination.</p></div></div>
      <Callout icon={Star}>Technology is a skill you build with practice—not simply a subject you memorize.</Callout>
    </>;
    case 7: return <><FrameTitle eyebrow="WHAT YOU WILL ACHIEVE" title="Our learning" important="objectives" description="By the end of the term, you should be able to…"/>
      <div className="objectives-grid">{[
        'Understand essential devices, computer systems, and software.',
        'Practice ethical and responsible digital citizenship.',
        'Find, evaluate, and manage trustworthy information.',
        'Recognize principles of digital content creation.',
        'Communicate and collaborate appropriately online.',
        'Identify common cybersecurity and privacy risks.',
        'Prepare for the IC3 GS6 Level 1 certification exam.'
      ].map((t,i)=><div className="glass-card objective" key={t}><div className="objective-check"><Check size={18}/></div><span>{t}</span><small>0{i+1}</small></div>)}</div>
    </>;
    case 8: return <div className="professor-layout">
      <div className="portrait-wrap"><div className="portrait-halo"/><img className="portrait" src={ASSETS+'professor-ej-diaz.png'} alt="Professor Ernest Joshua M. Diaz"/><div className="photo-ribbon"><BadgeCheck size={18}/> YOUR COURSE PROFESSOR</div></div>
      <div className="professor-content"><div className="eyebrow"><span className="eyebrow-dot"/>LET'S GET ACQUAINTED</div><h1>Meet your <span className="red-accent">professor</span></h1><h2>ERNEST JOSHUA M. DIAZ</h2><div className="degree">LPT, MIT · Certified I.T. Educator and AI Specialist</div><div className="highlight-rule"/><p>IT educator and practitioner working across software development, artificial intelligence, project management, and technology training.</p>
        <div className="professor-stats"><div><strong>137</strong><span>IT-related projects handled*</span></div><div><strong>230+</strong><span>Professional certifications*</span></div></div>
        <div className="professor-roles"><span><GraduationCap size={16}/> Lecturer · NU Clark & Pampanga State University</span><span><Award size={16}/> Former VP for Operations · SATEZO</span><span><Mic2 size={16}/> IT Resource Speaker & Trainer</span></div>
        <small>*Project and certification counts provided by the instructor.</small>
      </div>
    </div>;
    case 9: return <><FrameTitle eyebrow="HOW WE WILL LEARN" title="A student-centered" important="classroom" description="You are not just listeners. You are active participants in your learning."/>
      <div className="grid-three"><IconCard icon={MessagesSquare} title="Interactive Discussions" description="Ask questions, explain ideas, and exchange perspectives."/><IconCard icon={UsersRound} title="Group Challenges" description="Collaborate through practical problem-solving activities."/><IconCard icon={Laptop} title="Hands-on Learning" description="Use digital tools to understand real situations."/><IconCard icon={BrainCircuit} title="Critical Thinking" description="Assess information instead of automatically accepting it."/><IconCard icon={ClipboardCheck} title="Frequent Feedback" description="Learn from quizzes, activities, and mock certification tests."/><IconCard icon={HeartPulse} title="MedTech Relevance" description="Connect foundational digital skills to healthcare work." accent="red"/></div>
    </>;
    case 10: return <><FrameTitle eyebrow="CLASSROOM AGREEMENTS" title="Our classroom" important="policies" description="Professionalism, integrity, and consistency matter."/>
      <div className="grid-two big-tiles"><IconCard icon={CalendarDays} title="Attendance Matters" description="Maintain at least 80% attendance for the trimester, as required by the class policy."/><IconCard icon={GraduationCap} title="Complete Uniform" description="The prescribed uniform is required. Noncompliance is treated as an absence and restricts examinations under the stated policy." accent="red"/><IconCard icon={FileCheck2} title="Special Exams" description="Special examinations are granted only for properly documented excused absences."/><IconCard icon={ShieldAlert} title="No Cheating" description="Academic dishonesty, plagiarism, impersonation, and unauthorized help are not tolerated." accent="red"/></div>
      <Callout icon={CircleAlert} type="red">Class policies will be administered in accordance with applicable university regulations.</Callout>
    </>;
    case 11: return <><FrameTitle eyebrow="BE ON TIME" title="Attendance" important="monitoring" description="A 15-minute grace period applies at the beginning of class."/>
      <div className="attendance-grid">
        <div className="glass-card attendance-tile"><span className="attendance-state blue"><CheckCircle2/>PRESENT</span><h2>0–15 <small>minutes</small></h2><p>Within the grace period</p><strong>No deduction</strong></div>
        <div className="glass-card attendance-tile"><span className="attendance-state gold"><Clock3/>LATE</span><h2>16–30 <small>minutes</small></h2><p>After the grace period</p><strong>−0.5 point</strong></div>
        <div className="glass-card attendance-tile"><span className="attendance-state red"><CircleAlert/>ABSENT</span><h2>31+ <small>minutes</small></h2><p>More than 30 minutes late</p><strong>−1.0 point</strong></div>
      </div>
      <Callout icon={ClipboardList}>Deductions apply to the attendance component in the class record. Attendance remains subject to the 80% trimester requirement.</Callout>
    </>;
    case 12: return <><FrameTitle eyebrow="IMPORTANT REMINDERS" title="Excused absences &" important="class breaks" description="Keep your supporting documents ready and respect our instructional time."/>
      <div className="grid-two detail-grid"><div className="glass-card detail-block"><div className="detail-icon"><HeartPulse size={35}/></div><h2>Medical Absences</h2><p>No attendance-point deduction for valid medical absences when supported by a doctor's medical certificate <b>signed or validated by the university Health Services Office</b>.</p><span className="detail-footer"><CheckCircle2 size={18}/> Proper documentation is required</span></div><div className="glass-card detail-block"><div className="detail-icon red"><FileCheck2 size={35}/></div><h2>Excuse & Special Exams</h2><p>For excused absences, submit the required <b>parent/guardian-signed excuse letter</b> or, in cases of illness, the required medical certification. Special examinations are for valid excused absences only.</p><span className="detail-footer"><ShieldCheck size={18}/> Subject to university procedures</span></div></div>
      <div className="glass-card break-banner"><Timer size={29}/><div><b>15–20 Minute Class Break</b><span>The length depends on available time. Please return promptly.</span></div></div>
    </>;
    case 13: return <><FrameTitle eyebrow="DIGITAL-FIRST CLASSROOM" title="We practice what we" important="study" description="Because this course is about the I.T. era, our assessments will embrace digital tools."/>
      <div className="digital-panel"><div className="glass-card digital-primary"><Smartphone size={72}/><span>DIGITAL ASSESSMENTS</span><h2>Your device becomes your learning tool.</h2><p>Quizzes will be completed digitally through ZipGrade. Bring a phone, tablet, or laptop with internet access.</p></div><div className="digital-points"><IconCard icon={Wifi} title="Internet Ready" description="Ensure you can connect during class and assessment sessions."/><IconCard icon={Laptop} title="Charge Your Device" description="Come prepared with a working, charged mobile device or computer."/><IconCard icon={PenLine} title="Midterm Exception" description="The Midterm Examination may use printed materials." accent="red"/></div></div>
    </>;
    case 14: return <><FrameTitle eyebrow="CLASS ACTIVITIES" title="Assessments made" important="interactive" description="Expect short tasks, guided practice, and certification-oriented questions."/>
      <div className="grid-three"><IconCard icon={Smartphone} title="Digital Quizzes" description="Complete scheduled quizzes using ZipGrade and your own device."/><IconCard icon={Search} title="Scenario Questions" description="Apply digital literacy knowledge to realistic situations."/><IconCard icon={UsersRound} title="Collaborative Tasks" description="Take part in guided group discussions and classroom exercises."/><IconCard icon={ClipboardCheck} title="Skills Checkpoints" description="Use practice assessments to discover areas for improvement."/><IconCard icon={Award} title="Mock Certification" description="Review GS6 Level 1 concepts before your official examination."/><IconCard icon={ShieldCheck} title="Academic Integrity" description="Complete all tasks honestly and follow examination instructions." accent="red"/></div>
      <Callout icon={Lightbulb}>Unless the professor announces otherwise, quizzes are paperless. The midterm is the planned exception.</Callout>
    </>;
    case 15: return <><FrameTitle eyebrow="HOW YOUR GRADES WORK" title="Midterm grading" important="system" description="The official midterm grade has two components."/>
      <div className="grade-layout"><div className="glass-card grade-main"><Bar name="Learning activities" value={60}/><div className="activity-mini">Assignments · Quizzes · Exercises · Board work · Recitation</div><Bar name="Midterm examination" value={40} accent="red"/><div className="grade-formula">MIDTERM GRADE = <b>(Activities × 0.60) + (Exam × 0.40)</b></div></div><div className="glass-card grade-donut"><div className="donut" style={{'--share':'60%'}}><div><strong>60<span>%</span></strong><small>Learning</small></div></div><p>Activities carry the greater weight. Consistent participation matters.</p></div></div>
    </>;
    case 16: return <><FrameTitle eyebrow="HOW YOUR GRADES WORK" title="Final-term grading" important="system" description="Keep building your skills after the midterm examination."/>
      <div className="grade-layout"><div className="glass-card grade-main"><Bar name="Learning activities" value={60}/><div className="activity-mini">Activities, quizzes, exercises, and learning tasks</div><Bar name="Final examination" value={40} accent="red"/><div className="grade-formula">FINAL TERM GRADE = <b>(Activities × 0.60) + (Exam × 0.40)</b></div></div><div className="glass-card grade-donut"><div className="donut" style={{'--share':'60%'}}><div><strong>40<span>%</span></strong><small>Final exam</small></div></div><p>The IC3 certification examination is the culminating course requirement.</p></div></div>
      <Callout icon={CircleHelp}>Certification score reporting and its relationship to the final examination component follow approved class/university procedures.</Callout>
    </>;
    case 17: return <><FrameTitle eyebrow="TOTAL COURSE PERFORMANCE" title="Final course" important="grade" description="Your midterm and final-term grades contribute equally to your final result."/>
      <div className="grid-two final-grade-grid"><div className="final-math glass-card"><div className="equation-row"><span>Midterm Grade</span><b>50%</b></div><div className="math-plus">+</div><div className="equation-row"><span>Final Term Grade</span><b>50%</b></div><div className="equation-rule"/><h2>FINAL COURSE GRADE</h2><p>(Midterm × 0.50) + (Final Term × 0.50)</p></div><GradeCalculator/></div>
      <Callout icon={CheckCircle2}>Passing grade: <b>60%</b> on a <b>base-0 grading system</b>.</Callout>
    </>;
    case 18: return <><FrameTitle eyebrow="UNIVERSITY GRADING SCALE" title="Grade" important="equivalents" description="Know how your final percentage corresponds to the university grade point."/>
      <div className="equivalent-layout"><GradeTable/><div className="equivalent-side"><div className="glass-card equivalent-summary"><div className="equiv-badge"><Trophy size={34}/></div><h2>60%</h2><strong>Minimum passing grade</strong><p>A final percentage of 60–65 corresponds to a grade point of 1.0.</p></div><Callout icon={CircleAlert} type="red">59% and below receives the grade equivalent <b>R</b>.</Callout></div></div>
    </>;
    case 19: return <><FrameTitle eyebrow="MY TEACHING PRINCIPLE" title="What You Give Is" important="What You Get" description="Transparency. Fairness. Accountability."/>
      <div className="transparency-layout"><div className="glass-card quote-card"><span className="quotation">“</span><h2>You should never be surprised by your final grade.</h2><p>Every recorded activity, quiz, and examination score should be visible to you as your class record is updated.</p></div><div className="commitments"><IconCard icon={Eye} title="Visibility" description="View assessment results through your individual student portal."/><IconCard icon={MessagesSquare} title="Early Communication" description="Raise discrepancies or concerns as soon as they appear."/><IconCard icon={Target} title="Personal Accountability" description="Track progress and take action before the final examination." accent="red"/></div></div>
    </>;
    case 20: return <><FrameTitle eyebrow="STUDENT GRADE MONITORING" title="Know your grades in" important="real time" description="A dedicated Student Portal is planned for individual score monitoring."/>
      <div className="portal-preview"><div className="glass-card portal-screen"><div className="portal-screen-head"><div className="portal-dots"><i/><i/><i/></div><strong>STUDENT GRADE PORTAL</strong><span>CONCEPT PREVIEW</span></div><div className="portal-content"><div className="portal-avatar"><UserCircle2 size={42}/></div><h2>My Academic Record</h2><div className="portal-placeholder"><LockKeyhole size={20}/> Secure student sign-in / verification</div><div className="portal-skeleton"><span/><span/><span/></div><div className="portal-note">This presentation is a preview. No actual student grades or login system are included.</div></div></div><div className="portal-steps"><InfoStack items={[{icon:Fingerprint,title:'1. Verify Identity',text:'Use your Student ID with appropriate secure verification.'},{icon:Eye,title:'2. Check Scores',text:'See scores after the professor records and publishes them.'},{icon:MessageCircle,title:'3. Report Concerns',text:'Ask about discrepancies early, not after the term.'}]} /></div></div>
    </>;
    case 21: return <><FrameTitle eyebrow="YOUR CULMINATING REQUIREMENT" title="IC3 Certification" important="Examination" description="The goal of our entire course is preparation for a recognized digital literacy credential."/>
      <div className="cert-exam-layout"><div className="glass-card exam-large"><div className="exam-mark"><Award size={58}/></div><span>CERTIPORT IC3 DIGITAL LITERACY</span><h2>GLOBAL STANDARD SIX</h2><strong>LEVEL 1 – FOUNDATIONS</strong><p>Official certification examination required for GEITE01X.</p></div><div className="exam-key-points"><div className="glass-card exam-point"><CheckCircle2/><div><b>Foundational Knowledge</b><span>Know core digital concepts and safe habits.</span></div></div><div className="glass-card exam-point"><ClipboardCheck/><div><b>Practice and Review</b><span>Revisit questions and weak domains throughout the term.</span></div></div><div className="glass-card exam-point"><Star/><div><b>Exam Readiness</b><span>Arrive prepared, confident, and informed about the examination process.</span></div></div></div></div>
    </>;
    case 22: return <><FrameTitle eyebrow="TIME TO GET TO KNOW YOU" title="Let's Connect:" important="Me, Myself & Technology" description="A quick and friendly icebreaker before we begin learning together."/>
      <div className="icebreaker-intro"><div className="glass-card intro-left"><div className="intro-emblem"><UsersRound size={55}/></div><h2>No right or wrong answers!</h2><p>We want to know the person behind the screen—not just the student ID.</p><span>FUN · FRIENDLY · DIGITAL</span></div><div className="intro-steps"><div className="glass-card step-line"><b>01</b><span><strong>Pick a student</strong><small>We will randomly select one name.</small></span></div><div className="glass-card step-line"><b>02</b><span><strong>Introduce yourself</strong><small>Name, nickname, and one interesting fact.</small></span></div><div className="glass-card step-line"><b>03</b><span><strong>Answer your question</strong><small>One random question about you and technology.</small></span></div><div className="glass-card step-line"><b>04</b><span><strong>Next participant!</strong><small>No repeats until everyone has been called.</small></span></div></div></div>
    </>;
    case 23: return <><div className="picker-title"><div className="eyebrow"><span className="eyebrow-dot"/>LET'S CONNECT: ME, MYSELF & TECHNOLOGY</div><h1>Random <span className="red-accent">Student Picker</span></h1><p>45 icebreaker questions · 2 sections · one fun introduction at a time</p></div><Randomizer isActive={isActive}/></>;
    case 24: return <div className="closing-layout"><div className="closing-orbit"><div className="closing-orbit-inner"><GraduationCap size={72}/></div></div><div className="eyebrow"><span className="eyebrow-dot"/>GEITE01X · AY 2026–2027</div><h1>YOUR DIGITAL JOURNEY<br/><span className="red-accent">STARTS TODAY.</span></h1><div className="highlight-rule"/><p>Be curious. Participate actively. Practice consistently.<br/>Use technology with knowledge, confidence, and integrity.</p><div className="closing-words"><span>LEARN</span><i/><span>PRACTICE</span><i/><span>CERTIFY</span></div><div className="closing-small">WELCOME, MED204 & MED205!</div></div>;
    default: return null;
  }
}

export default function App() {
  const [index,setIndex] = useState(0);
  const [direction,setDirection] = useState(1);
  const [isFull,setIsFull] = useState(Boolean(document.fullscreenElement));
  const [helpOpen,setHelpOpen] = useState(false);
  const prefersReducedMotion = useReducedMotion();
  const startX = useRef(null);
  const stageRef = useRef(null);
  useEffect(() => { if (stageRef.current) stageRef.current.scrollTop = 0; }, [index]);
  const jump = useCallback(next => {
    const target = Math.max(0, Math.min(slides.length-1, typeof next === 'function' ? next(index) : next));
    if (target === index) return;
    setDirection(target > index ? 1 : -1);
    setIndex(target);
  }, [index]);
  const nextSlide = useCallback(()=>jump(i=>i+1),[jump]);
  const previousSlide = useCallback(()=>jump(i=>i-1),[jump]);
  const toggleFullscreen = useCallback(async()=>{
    try { if(document.fullscreenElement) await document.exitFullscreen(); else await document.documentElement.requestFullscreen(); }
    catch(e) { /* browsers may disable fullscreen for some embeds */ }
  },[]);
  useEffect(()=>{
    function onFull(){setIsFull(Boolean(document.fullscreenElement));}
    document.addEventListener('fullscreenchange',onFull);
    return ()=>document.removeEventListener('fullscreenchange',onFull);
  },[]);
  useEffect(()=>{
    function onKey(e){
      const active=document.activeElement;
      const tag=active?.tagName?.toLowerCase();
      if(tag==='input'||tag==='textarea'||tag==='select'||active?.isContentEditable) return;
      if(document.querySelector('[role="dialog"]')) return;
      if(helpOpen){if(e.key==='Escape'){setHelpOpen(false);e.preventDefault();}return;}
      if(e.key==='ArrowRight'||e.key==='PageDown'){e.preventDefault();nextSlide();}
      else if(e.key==='ArrowLeft'||e.key==='PageUp'){e.preventDefault();previousSlide();}
      else if(e.key==='Home'){e.preventDefault();jump(0);}
      else if(e.key==='End'){e.preventDefault();jump(slides.length-1);}
      else if(e.key==='f'||e.key==='F'){e.preventDefault();toggleFullscreen();}
      else if(e.key==='?' ){e.preventDefault();setHelpOpen(true);}
    }
    window.addEventListener('keydown',onKey);
    return ()=>window.removeEventListener('keydown',onKey);
  },[helpOpen,jump,nextSlide,previousSlide,toggleFullscreen]);
  const slideMotion = prefersReducedMotion ? {initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},transition:{duration:0.12}} : {
    initial:{opacity:0,x:direction>0?72:-72,filter:'blur(7px)',scale:0.985},
    animate:{opacity:1,x:0,filter:'blur(0px)',scale:1},
    exit:{opacity:0,x:direction>0?-48:48,filter:'blur(4px)',scale:0.99},
    transition:{duration:0.38,ease:[0.2,0.8,0.2,1]},
  };
  return <div className="app-shell" onTouchStart={e=>{if(!e.target.closest('button,input,textarea,select,[role="dialog"]'))startX.current=e.touches[0]?.clientX ?? null;}}
    onTouchEnd={e=>{if(startX.current===null||document.querySelector('[role="dialog"]'))return;const diff=(e.changedTouches[0]?.clientX??startX.current)-startX.current;startX.current=null;if(Math.abs(diff)>80){if(diff<0)nextSlide();else previousSlide();}}}>
    <div className="ambient ambient-a"/><div className="ambient ambient-b"/><div className="ambient ambient-c"/>
    <header className="presentation-header">
      <div className="brand-lockup"><img src={ASSETS+'nu-logo.svg'} alt="National University logo"/><div><strong>NATIONAL UNIVERSITY</strong><span>CLARK · COURSE ORIENTATION</span></div></div>
      <div className="header-course">GEITE01X <span>•</span> LIVING IN THE I.T. ERA</div>
      <div className="header-actions"><button className="utility" title="Keyboard shortcuts (?)" aria-label="Keyboard help" onClick={()=>setHelpOpen(true)}><CircleHelp size={19}/></button><button className="utility" onClick={toggleFullscreen} title="Fullscreen (F)" aria-label={isFull?'Exit fullscreen':'Enter fullscreen'}>{isFull?<Minimize2 size={19}/>:<Maximize2 size={19}/>}</button></div>
    </header>
    <main ref={stageRef} className="stage" aria-label={slides[index].label}>
      <AnimatePresence mode="wait" initial={false}>
        <motion.section className="slide" key={index} {...slideMotion}>
          <SlideContent index={index} isActive={true}/>
        </motion.section>
      </AnimatePresence>
    </main>
    <footer className="presentation-footer">
      <div className="slide-context"><span className="slide-section">{slides[index].section}</span><strong>{slides[index].label}</strong></div>
      <div className="slide-nav"><button className="circle-btn back" onClick={previousSlide} disabled={index===0} aria-label="Previous slide" title="Previous slide (←)"><ChevronLeft size={26}/></button>
        <div className="slide-count"><span>{String(index+1).padStart(2,'0')}</span><i>/</i><span>{String(slides.length).padStart(2,'0')}</span></div>
        <button className="circle-btn forward" onClick={nextSlide} disabled={index===slides.length-1} aria-label="Next slide" title="Next slide (→)"><ChevronRight size={26}/></button></div>
      <div className="footer-hint"><Keyboard size={17}/> <span>Use ← → to navigate</span></div>
    </footer>
    <div className="progress-track" aria-hidden="true"><span style={{width:((index+1)/slides.length*100)+'%'}}/></div>
    {helpOpen && <div className="modal-scrim help-overlay" role="presentation" onMouseDown={e=>{if(e.target===e.currentTarget)setHelpOpen(false)}}><div className="help-card" role="dialog" aria-modal="true" aria-label="Presentation shortcuts"><button className="icon-button help-close" onClick={()=>setHelpOpen(false)} aria-label="Close help"><X size={22}/></button><Keyboard size={36}/><h2>Presentation Controls</h2><p>Navigate the portal just like a PowerPoint presentation.</p><div><span>Next / Previous</span><b>← →</b></div><div><span>First / Last slide</span><b>Home / End</b></div><div><span>Fullscreen</span><b>F</b></div><div><span>Open help</span><b>?</b></div><small>On mobile, swipe left or right. For the student randomizer, import your class list first.</small></div></div>}
  </div>;
}
